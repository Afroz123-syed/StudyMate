import streamlit as st
from pdf_processor import extract_text_from_pdf
from embedder import chunk_text, create_faiss_index
from qa_engine import search_chunks, ask_llm
from utils import build_prompt

st.set_page_config(page_title="StudyMate", layout="centered")

st.title("📘 StudyMate - Ask Your PDFs Anything")

uploaded_file = st.file_uploader("Upload PDF", type=["pdf"])

if uploaded_file:
    text = extract_text_from_pdf(uploaded_file)
    chunks = chunk_text(text)
    index, embeddings, chunk_list = create_faiss_index(chunks)
    st.success("PDF processed successfully!")

    question = st.text_input("Ask a question from the document:")

    if question:
        relevant_chunks = search_chunks(question, index, chunk_list, embeddings)
        prompt = build_prompt(relevant_chunks, question)
        with st.spinner("Getting answer from AI..."):
            answer = ask_llm(prompt)
        st.markdown("### Answer:")
        st.write(answer)