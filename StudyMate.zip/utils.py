def build_prompt(context_chunks, question):
    context = "\n".join(context_chunks)
    prompt = f"""You are an AI assistant. Use the following context to answer the question.

Context:
{context}

Question: {question}
Answer:"""
    return prompt