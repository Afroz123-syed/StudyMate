import numpy as np
from embedder import model
import requests
import os

def search_chunks(query, index, chunks, embeddings, k=3):
    query_vec = model.encode([query])
    D, I = index.search(np.array(query_vec), k)
    return [chunks[i] for i in I[0]]

def ask_llm(prompt):
    API_KEY = os.getenv("WATSON_API_KEY")
    ENDPOINT = os.getenv("WATSON_ENDPOINT")

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }
    payload = {
        "model": "mistralai/mixtral-8x7b-instruct",
        "input": prompt,
        "parameters": {"max_tokens": 512}
    }

    response = requests.post(ENDPOINT, headers=headers, json=payload)
    return response.json()["results"][0]["generated_text"]